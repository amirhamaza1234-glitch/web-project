const quizData = [
    // Programming & OOPS
    { question: "Which of the following is not an OOPS concept?", options: ["Inheritance", "Encapsulation", "Compilation", "Polymorphism"], answer: 2 },
    { question: "Which keyword is used to inherit a class in Java?", options: ["this", "super", "extends", "implement"], answer: 2 },
    { question: "What is the default value of an int variable in Java?", options: ["0", "null", "undefined", "garbage value"], answer: 0 },
    { question: "Which data structure uses LIFO?", options: ["Queue", "Stack", "Array", "Linked List"], answer: 1 },
    { question: "Which of the following is a linear data structure?", options: ["Tree", "Graph", "Array", "Heap"], answer: 2 },
    // Data Structures
    { question: "Time complexity of binary search?", options: ["O(n)", "O(n²)", "O(log n)", "O(1)"], answer: 2 },
    { question: "Which data structure is used for BFS?", options: ["Stack", "Queue", "Heap", "Tree"], answer: 1 },
    { question: "Which traversal gives sorted output in BST?", options: ["Preorder", "Postorder", "Inorder", "Level order"], answer: 2 },
    { question: "Worst case time complexity of Quick Sort?", options: ["O(n log n)", "O(n²)", "O(log n)", "O(n)"], answer: 1 },
    { question: "Which collision technique uses linked list?", options: ["Linear Probing", "Quadratic Probing", "Chaining", "Double Hashing"], answer: 2 },
    // Operating System
    { question: "Which scheduling algorithm may cause starvation?", options: ["FCFS", "SJF", "Round Robin", "FIFO"], answer: 1 },
    { question: "Deadlock occurs when?", options: ["One process waiting", "Mutual exclusion exists", "Circular wait exists", "CPU is idle"], answer: 2 },
    { question: "Which memory is volatile?", options: ["ROM", "Hard Disk", "RAM", "SSD"], answer: 2 },
    { question: "Paging is used to solve?", options: ["Fragmentation", "Deadlock", "Scheduling", "Thrashing"], answer: 0 },
    { question: "Thrashing occurs when?", options: ["High CPU usage", "Excessive paging", "Low memory", "Disk failure"], answer: 1 },
    // Database (DBMS)
    { question: "What does ACID stand for?", options: ["Atomicity, Consistency, Isolation, Durability", "Accuracy, Clarity, Integrity, Data", "Atomic, Control, Isolation, Data", "None"], answer: 0 },
    { question: "Which normal form removes transitive dependency?", options: ["1NF", "2NF", "3NF", "BCNF"], answer: 2 },
    { question: "SQL command to remove a table?", options: ["DELETE", "REMOVE", "DROP", "CLEAR"], answer: 2 },
    { question: "Primary key cannot contain?", options: ["Unique values", "Duplicate values", "Integers", "Strings"], answer: 1 },
    { question: "Which join returns all records from both tables?", options: ["Inner Join", "Left Join", "Right Join", "Full Outer Join"], answer: 3 },
    // Computer Networks
    { question: "OSI model has how many layers?", options: ["5", "6", "7", "8"], answer: 2 },
    { question: "HTTP works on which port?", options: ["20", "21", "80", "443"], answer: 2 },
    { question: "Which protocol is connection-oriented?", options: ["UDP", "TCP", "HTTP", "FTP"], answer: 1 },
    { question: "IP address version 4 size?", options: ["16 bit", "32 bit", "64 bit", "128 bit"], answer: 1 },
    { question: "DNS is used for?", options: ["Data transfer", "Name resolution", "Security", "Routing"], answer: 1 },
    // Software Engineering
    { question: "SDLC stands for?", options: ["Software Development Life Cycle", "System Design Level Code", "Software Data Link Control", "None"], answer: 0 },
    { question: "Agile model focuses on?", options: ["Documentation", "Iterative development", "One-time delivery", "Testing only"], answer: 1 },
    { question: "Which model is linear?", options: ["Agile", "Spiral", "Waterfall", "RAD"], answer: 2 },
    { question: "Black box testing checks?", options: ["Internal code", "Functionality", "Database", "Performance"], answer: 1 },
    { question: "White box testing checks?", options: ["UI", "Requirements", "Internal logic", "Users"], answer: 2 },
    // C / C++ / Python
    { question: "Which symbol is used for pointer in C?", options: ["&", "*", "#", "@"], answer: 1 },
    { question: "sizeof(int) in C is usually?", options: ["2", "4", "8", "Depends on compiler"], answer: 3 },
    { question: "Python is which type of language?", options: ["Compiled", "Interpreted", "Machine", "Assembly"], answer: 1 },
    { question: "Which function is used to read input in Python?", options: ["read()", "input()", "scan()", "get()"], answer: 1 },
    { question: "Which operator is used for exponent in Python?", options: ["^", "**", "//", "%%"], answer: 1 },
    // Miscellaneous Core Concepts
    { question: "Compiler converts?", options: ["Machine to High level", "High level to Machine", "Assembly to High", "Binary to Decimal"], answer: 1 },
    { question: "Which is non-linear data structure?", options: ["Array", "Stack", "Tree", "Queue"], answer: 2 },
    { question: "Big O notation measures?", options: ["Space only", "Time only", "Complexity", "Memory"], answer: 2 },
    { question: "Recursion uses?", options: ["Queue", "Stack", "Heap", "Tree"], answer: 1 },
    { question: "HTML stands for?", options: ["High Text Machine Language", "Hyper Text Markup Language", "Hyper Tool Mark Language", "None"], answer: 1 },
    // Advanced / Interview Level
    { question: "Which sorting is stable?", options: ["Quick Sort", "Heap Sort", "Merge Sort", "Selection Sort"], answer: 2 },
    { question: "Which data structure is used in Dijkstra's algorithm?", options: ["Stack", "Queue", "Priority Queue", "Tree"], answer: 2 },
    { question: "Which SQL clause is used to filter groups?", options: ["WHERE", "GROUP BY", "HAVING", "ORDER BY"], answer: 2 },
    { question: "REST stands for?", options: ["Remote Execution System Transfer", "Representational State Transfer", "Real State Transfer", "None"], answer: 1 },
    { question: "Which layer handles encryption in OSI?", options: ["Application", "Transport", "Presentation", "Network"], answer: 2 },
    { question: "Which search is best for sorted array?", options: ["Linear", "Binary", "DFS", "BFS"], answer: 1 },
    { question: "Which is used to prevent SQL injection?", options: ["CSS", "Prepared Statements", "JavaScript", "HTML"], answer: 1 },
    { question: "Git is a?", options: ["Programming Language", "Database", "Version Control System", "OS"], answer: 2 },
    { question: "Virtual memory uses?", options: ["RAM only", "Cache", "Disk space", "ROM"], answer: 2 },
    { question: "Which algorithm is used for minimum spanning tree?", options: ["Dijkstra", "Prim’s", "BFS", "DFS"], answer: 1 }
];

const quizContainer = document.getElementById('quiz');
const submitBtn = document.getElementById('submit-btn');
const resultContainer = document.getElementById('result');

// 1. Function to display the quiz
function loadQuiz() {
    quizData.forEach((currentQuestion, questionIndex) => {
        // Create a div for each question
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question');
        questionDiv.innerHTML = `<h3>${questionIndex + 1}. ${currentQuestion.question}</h3>`;

        // Create options for each question
        currentQuestion.options.forEach((option, optionIndex) => {
            const label = document.createElement('label');
            label.classList.add('option');
            
            // Create radio button
            const input = document.createElement('input');
            input.type = 'radio';
            input.name = `question${questionIndex}`; // Group radio buttons by question
            input.value = optionIndex;

            label.appendChild(input);
            label.appendChild(document.createTextNode(option));
            questionDiv.appendChild(label);
        });

        quizContainer.appendChild(questionDiv);
    });
}

// 2. Function to calculate score
submitBtn.addEventListener('click', () => {
    let score = 0;
    
    quizData.forEach((currentQuestion, questionIndex) => {
        // Find the selected radio button for this question
        const selectedOption = document.querySelector(`input[name="question${questionIndex}"]:checked`);
        
        if (selectedOption) {
            // Check if selected value matches the correct answer index
            if (parseInt(selectedOption.value) === currentQuestion.answer) {
                score++;
            }
        }
    });

    // Display result
    resultContainer.style.display = 'block';
    resultContainer.innerHTML = `You scored ${score} out of ${quizData.length}`;
    
    // Optional: Change color based on score
    if(score > (quizData.length / 2)) {
        resultContainer.style.color = "green";
    } else {
        resultContainer.style.color = "red";
    }
});

// Initialize the quiz
loadQuiz();